#include <iostream>
#include "contact.h"

int main()
{
	ListaContacte l(20);
	l.adauga();
	l.adauga();
	l.stergere();
	l.afisare();

	return 0;
}
